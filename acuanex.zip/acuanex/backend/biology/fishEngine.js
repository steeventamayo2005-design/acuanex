﻿const EventBus = require('../eventBus');

class FishEngine {
    constructor(stateManager) {
        this.state = stateManager;
    }
    
    update(dt) {
        const f = this.state.state.fish;
        const w = this.state.state.water;
        const cfg = require('../../config/species.json')[f.species];
        if (!cfg) return;
        
        // Factores ambientales
        const tempF = this.tempFactor(w.temperature, cfg.water.temperature);
        const oxyF = Math.min(1, w.oxygen / cfg.water.oxygen.optimal);
        const nh3F = Math.max(0, 1 - w.ammonia / cfg.water.ammonia.max);
        
        // Crecimiento (SGR - Specific Growth Rate)
        const sgr = cfg.growth.growthRate * tempF * oxyF * nh3F;
        const prevW = f.averageWeight;
        f.averageWeight = Math.min(cfg.growth.maxWeight, prevW * Math.exp(sgr * dt));
        f.totalBiomass = (f.population * f.averageWeight) / 1000;
        
        // Alimentación
        f.dailyFeed = Math.max(0.1, f.totalBiomass * cfg.growth.dailyFeedRate * tempF);
        
        // FCR (Feed Conversion Ratio)
        const wg = (f.averageWeight - prevW) * f.population / 1000;
        f.fcr = wg > 0 ? (f.dailyFeed * dt) / wg : cfg.growth.fcr;
        
        // Tiempo en cultivo
        f.daysInCulture += dt;
        
        // Estrés (0-10)
        f.stressLevel = Math.round((1 - tempF) * 4 + (1 - oxyF) * 3 + (1 - nh3F) * 3);
        
        // Mortalidad por estrés
        if (f.stressLevel > 7) {
            const d = Math.max(1, Math.floor(f.population * (f.stressLevel - 6) * 0.001 * dt));
            f.population -= d;
            f.mortality += d;
            if (d > 0) {
                EventBus.emit('alarm', {
                    type: 'critical',
                    title: '💀 MORTALIDAD',
                    message: d + ' peces muertos (estres: ' + f.stressLevel + '/10)'
                });
            }
        }
        
        // Consumir alimento del stock
        const feed = this.state.state.feeding;
        feed.feedInStock = Math.max(0, (feed.feedInStock || 200) - f.dailyFeed * dt);
        feed.totalFeedConsumed += f.dailyFeed * dt;
        
        if (feed.feedInStock < f.dailyFeed * 3) {
            EventBus.emit('alarm', {
                type: 'warning',
                title: '📦 ALIMENTO BAJO',
                message: 'Quedan ' + feed.feedInStock.toFixed(0) + ' kg'
            });
        }
    }
    
    tempFactor(t, r) {
        if (t < r.min - 3 || t > r.max + 3) return 0.1;
        if (t < r.min || t > r.max) return 0.5;
        const o = r.optimal || (r.min + r.max) / 2;
        return 1 - Math.abs(t - o) / (r.max - r.min);
    }
}
module.exports = FishEngine;
