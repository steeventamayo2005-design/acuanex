﻿const fs = require('fs');
const path = require('path');

class StateManager {
    constructor() {
        this.state = {
            water: {
                temperature: 26.5,
                ph: 7.2,
                oxygen: 6.5,
                ammonia: 0.02,
                nitrite: 0.005,
                nitrate: 10.0,
                alkalinity: 80
            },
            fish: {
                species: 'tilapia',
                population: 500,
                averageWeight: 250,
                totalBiomass: 125,
                fcr: 1.4,
                dailyFeed: 3.75,
                mortality: 0,
                stressLevel: 2,
                daysInCulture: 45,
                harvestWeight: 500
            },
            feeding: {
                feedInStock: 200,
                totalFeedConsumed: 0
            },
            economics: {
                feedCostPerKg: 0.85,
                electricityCostPerDay: 3.5,
                fishPricePerKg: 4.5,
                totalCost: 0,
                totalRevenue: 0,
                profit: 0
            },
            actuators: {
                aerator: false,
                pump: false,
                heater: false
            },
            alerts: [],
            recommendations: []
        };
    }

    saveToFile(filePath) {
        const dir = path.dirname(filePath);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(filePath, JSON.stringify(this.state, null, 2));
    }

    loadFromFile(filePath) {
        if (fs.existsSync(filePath)) {
            try {
                const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
                if (data.water) this.state.water = data.water;
                if (data.fish) this.state.fish = data.fish;
                if (data.feeding) this.state.feeding = data.feeding;
                if (data.economics) this.state.economics = data.economics;
                return true;
            } catch(e) {
                console.error('Error cargando estado:', e.message);
            }
        }
        return false;
    }
}

module.exports = new StateManager();
