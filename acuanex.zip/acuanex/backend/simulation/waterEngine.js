﻿const EventBus = require('../eventBus');

class WaterEngine {
    constructor(stateManager, timeManager) {
        this.state = stateManager;
        this.time = timeManager;
    }
    
    update(dt) {
        const w = this.state.state.water;
        const f = this.state.state.fish;
        const a = this.state.state.actuators;
        const hf = this.time.getHourFactor();
        
        // Temperatura: varía con la hora del día
        w.temperature += hf * 0.15 * dt;
        
        // Oxígeno: consumido por peces, producido por aireador y fotosíntesis
        w.oxygen -= f.totalBiomass * 0.0004 * dt;
        if (a.aerator) w.oxygen += 0.8 * dt;
        if (hf > 0) w.oxygen += hf * 0.1 * dt;
        
        // Amoníaco: producido por peces
        w.ammonia += f.dailyFeed * 0.025 * dt;
        
        // Nitrificación: bacterias convierten NH3 → NO2 → NO3
        if (w.oxygen > 2 && w.temperature > 15) {
            const tf = Math.max(0.1, (w.temperature - 10) / 20);
            const nr = 0.15 * tf * dt;
            const ox = w.ammonia * nr;
            w.ammonia -= ox;
            w.nitrite += ox * 0.9;
            w.nitrite -= w.nitrite * nr * 0.8;
            w.nitrate += w.nitrite * nr * 0.8;
            w.alkalinity -= ox * 7.14 * 0.01;
        }
        
        // Limitar rangos físicos
        w.temperature = Math.max(5, Math.min(40, w.temperature));
        w.oxygen = Math.max(0, Math.min(15, w.oxygen));
        w.ammonia = Math.max(0, Math.min(1, w.ammonia));
        w.ph = Math.max(5, Math.min(9, w.ph + (Math.random() - 0.5) * 0.03));
        w.alkalinity = Math.max(10, w.alkalinity);
        
        // Verificar alarmas
        this.checkAlarms();
    }
    
    checkAlarms() {
        const w = this.state.state.water;
        const cfg = require('../../config/species.json')[this.state.state.fish.species];
        if (!cfg) return;
        
        if (w.oxygen < cfg.water.oxygen.min) {
            EventBus.emit('alarm', {
                type: 'critical',
                title: '🚨 OXIGENO BAJO',
                message: w.oxygen.toFixed(1) + ' mg/L - Activar aireador'
            });
        }
        if (w.ammonia > cfg.water.ammonia.max * 1.5) {
            EventBus.emit('alarm', {
                type: 'critical', 
                title: '⚠️ AMONIACO TOXICO',
                message: w.ammonia.toFixed(3) + ' ppm - Reducir alimentacion'
            });
        }
    }
}
module.exports = WaterEngine;
