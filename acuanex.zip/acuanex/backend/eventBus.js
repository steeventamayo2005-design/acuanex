﻿class EventBus {
    constructor() { this.listeners = {}; }
    on(e, cb) { if (!this.listeners[e]) this.listeners[e] = []; this.listeners[e].push(cb); }
    emit(e, d) { if (this.listeners[e]) this.listeners[e].forEach(cb => { try { cb(d); } catch(err) { console.error(err); } }); }
}
module.exports = new EventBus();
